# LiveUp FX – Animations 3D externes pour LiveUpCube

Datapack 100 % externe.  
Ne modifie **jamais** le plugin LiveUpCube.  
Utilise uniquement des **Display Entities** (item_display / block_display) pour des effets 3D solides.

Compatible Paper 1.21.x

---

## Installation

1. Place le dossier `liveup_fx` (ou le zip décompressé) dans :
   ```
   world/datapacks/
   ```
   (ou le monde où se trouve l’arène LiveUpCube)

2. En jeu ou console :
   ```
   /reload
   ```
   ou
   ```
   /datapack enable "file/liveup_fx"
   ```

3. Vérifie :
   ```
   /datapack list
   ```

---

## Utilisation (TikFinity / ServerTap / Console)

Remplace les anciennes commandes `/cube ...` par les fonctions ci-dessous.

### Exemples prêts à coller

**TNT (cadeau moyen)**
```
/function liveup_fx:epic/tnt {player:"PseudoStreamer", n:"15", viewer:"PseudoCadeau"}
```

**Diamant (cube plein)**
```
/function liveup_fx:epic/diamant {player:"PseudoStreamer", viewer:"PseudoCadeau"}
```

**Prison**
```
/function liveup_fx:epic/prison {player:"PseudoStreamer", sec:"30", viewer:"PseudoCadeau"}
```

**Fusée**
```
/function liveup_fx:epic/fusee {player:"PseudoStreamer", viewer:"PseudoCadeau"}
```

**Mega Fusée**
```
/function liveup_fx:epic/megafusee {player:"PseudoStreamer", viewer:"PseudoCadeau"}
```

**Follow / Abonné**
```
/function liveup_fx:epic/follow {player:"PseudoStreamer", viewer:"PseudoAbonne"}
```

**Roulette (gros cadeau)**
```
/function liveup_fx:epic/roulette {player:"PseudoStreamer", viewer:"PseudoCadeau"}
```

**Blocs (+n blocs)**
```
/function liveup_fx:epic/blocs {player:"PseudoStreamer", n:"50", viewer:"PseudoCadeau"}
```

**Retirer (malus)**
```
/function liveup_fx:epic/retirer {player:"PseudoStreamer", n:"25", viewer:"PseudoCadeau"}
```

---

## Personnalisation avec TON texture pack

Les modèles 3D actuels utilisent des items vanilla (end_crystal, amethyst_shard, nether_star, etc.).

Pour un rendu **100 % custom** :

1. Ouvre les fichiers dans `data/liveup_fx/function/internal/`
2. Remplace l’`id` de l’item par un item de ton pack (ex. `minecraft:paper` + CustomModelData)
3. Ou utilise directement un item custom de ton pack :
   ```
   item:{id:"minecraft:paper",count:1,components:{"minecraft:custom_model_data":1234}}
   ```
   (syntaxe 1.21)

Fichiers à modifier en priorité :
- `spawn_beam.mcfunction` → faisceau vertical
- `spawn_aura.mcfunction` → orbes autour du joueur
- `spawn_orbs.mcfunction` → orbes d’explosion
- `spawn_pillars.mcfunction` → piliers (actuellement light_blue_stained_glass)

---

## Nettoyage manuel

Si des displays restent bloqués :
```
/function liveup_fx:utils/cleanup
```

---

## Notes techniques

- Tous les displays portent le tag `liveup_fx` → nettoyage facile.
- L’interpolation native des Display Entities donne des animations fluides sans lag.
- Les commandes `/cube ...` sont appelées **après** les effets 3D.
- Aucun fichier du plugin LiveUpCube n’est modifié.
