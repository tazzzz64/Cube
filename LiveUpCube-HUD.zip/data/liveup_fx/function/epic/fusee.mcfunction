# ============================================================
# LIVEUP FX – FUSÉE 3D (pré-effet)
# Usage :
#   /function liveup_fx:epic/fusee {player:"PseudoStreamer", viewer:"PseudoCadeau"}
# ============================================================

function liveup_fx:utils/cleanup

# Anneaux d'énergie sous les pieds + traîne
$execute as $(player) at @s run summon item_display ~ ~0.3 ~ {Tags:["liveup_fx","liveup_fx_ring"],item:{id:"minecraft:end_crystal",count:1},item_display:"fixed",interpolation_duration:0,transformation:{left_rotation:[0.707f,0f,0f,0.707f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.8f,0.15f,1.8f]},brightness:{block:15,sky:15},view_range:2f}

$execute as $(player) at @s run summon item_display ~ ~0.8 ~ {Tags:["liveup_fx","liveup_fx_ring"],item:{id:"minecraft:end_crystal",count:1},item_display:"fixed",interpolation_duration:0,transformation:{left_rotation:[0.707f,0f,0f,0.707f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.4f,0.12f,1.4f]},brightness:{block:15,sky:15},view_range:2f}

$execute as $(player) at @s run function liveup_fx:internal/spawn_orbs

$execute as $(player) at @s run playsound minecraft:entity.firework_rocket.launch master @a[distance=..40] ~ ~ ~ 1.2 0.7
$execute as $(player) at @s run playsound minecraft:block.beacon.activate master @a[distance=..40] ~ ~ ~ 0.9 1.5

$cube fusee $(player) $(viewer)

schedule function liveup_fx:utils/cleanup 45t
