# ============================================================
# LIVEUP FX – BLOCS (aide)
# Usage :
#   /function liveup_fx:epic/blocs {player:"PseudoStreamer", n:"30", viewer:"PseudoCadeau"}
# ============================================================

function liveup_fx:utils/cleanup

$execute as $(player) at @s run function liveup_fx:internal/spawn_aura
$execute as $(player) at @s run function liveup_fx:internal/spawn_orbs

$execute as $(player) at @s run playsound minecraft:block.amethyst_block.chime master @a[distance=..30] ~ ~ ~ 1 1.2
$execute as $(player) at @s run playsound minecraft:entity.experience_orb.pickup master @a[distance=..30] ~ ~ ~ 1 0.8

$cube blocs $(player) $(n) $(viewer)

schedule function liveup_fx:utils/cleanup 30t
