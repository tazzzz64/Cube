# ============================================================
# LIVEUP FX – PRISON 3D
# Usage :
#   /function liveup_fx:epic/prison {player:"PseudoStreamer", sec:"30", viewer:"PseudoCadeau"}
# ============================================================

function liveup_fx:utils/cleanup

# Piliers rouges / barreaux stylisés
$execute as $(player) at @s run summon block_display ~-4 ~0.1 ~-4 {Tags:["liveup_fx","liveup_fx_pillar"],block_state:{Name:"minecraft:red_stained_glass"},interpolation_duration:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.5f,0f,-0.5f],scale:[0.8f,0.05f,0.8f]},brightness:{block:15,sky:15}}
$execute as $(player) at @s run summon block_display ~4 ~0.1 ~-4 {Tags:["liveup_fx","liveup_fx_pillar"],block_state:{Name:"minecraft:red_stained_glass"},interpolation_duration:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.5f,0f,-0.5f],scale:[0.8f,0.05f,0.8f]},brightness:{block:15,sky:15}}
$execute as $(player) at @s run summon block_display ~-4 ~0.1 ~4 {Tags:["liveup_fx","liveup_fx_pillar"],block_state:{Name:"minecraft:red_stained_glass"},interpolation_duration:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.5f,0f,-0.5f],scale:[0.8f,0.05f,0.8f]},brightness:{block:15,sky:15}}
$execute as $(player) at @s run summon block_display ~4 ~0.1 ~4 {Tags:["liveup_fx","liveup_fx_pillar"],block_state:{Name:"minecraft:red_stained_glass"},interpolation_duration:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.5f,0f,-0.5f],scale:[0.8f,0.05f,0.8f]},brightness:{block:15,sky:15}}

# Montée rapide des barreaux
$execute as $(player) at @s as @e[type=block_display,tag=liveup_fx_pillar,distance=..12] run data merge entity @s {interpolation_duration:8,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.5f,0f,-0.5f],scale:[0.8f,6f,0.8f]}}

$execute as $(player) at @s run function liveup_fx:internal/spawn_aura

$execute as $(player) at @s run playsound minecraft:block.iron_door.close master @a[distance=..30] ~ ~ ~ 1 0.7
$execute as $(player) at @s run playsound minecraft:entity.iron_golem.hurt master @a[distance=..30] ~ ~ ~ 0.8 0.5
$execute as $(player) at @s run summon lightning_bolt ~ ~ ~

$cube prison $(player) $(sec) $(viewer)

schedule function liveup_fx:utils/cleanup 40t
