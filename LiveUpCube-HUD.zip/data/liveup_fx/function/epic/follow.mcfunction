# ============================================================
# LIVEUP FX – FOLLOW / ABONNÉ 3D
# Usage :
#   /function liveup_fx:epic/follow {player:"PseudoStreamer", viewer:"PseudoAbonne"}
# ============================================================

function liveup_fx:utils/cleanup

$execute as $(player) at @s run function liveup_fx:internal/spawn_orbs
$execute as $(player) at @s run function liveup_fx:internal/spawn_aura

# Petits cubes verts qui apparaissent
$execute as $(player) at @s run summon item_display ~1.5 ~1 ~1.5 {Tags:["liveup_fx"],item:{id:"minecraft:emerald",count:1},item_display:"fixed",interpolation_duration:12,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.01f,0.01f,0.01f]},brightness:{block:15,sky:15}}
$execute as $(player) at @s run summon item_display ~-1.5 ~1.2 ~1 {Tags:["liveup_fx"],item:{id:"minecraft:emerald",count:1},item_display:"fixed",interpolation_duration:12,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.01f,0.01f,0.01f]},brightness:{block:15,sky:15}}

$execute as $(player) at @s as @e[type=item_display,tag=liveup_fx,distance=..5] run data merge entity @s {transformation:{scale:[0.6f,0.6f,0.6f]}}

$execute as $(player) at @s run playsound minecraft:entity.villager.celebrate master @a[distance=..30] ~ ~ ~ 1 1.1
$execute as $(player) at @s run playsound minecraft:block.note_block.chime master @a[distance=..30] ~ ~ ~ 1 1.5

$cube follow $(player) $(viewer)

schedule function liveup_fx:utils/cleanup 35t
