# ============================================================
# LIVEUP FX – DIAMANT / CUBE PLEIN 3D (version ultra)
# Usage :
#   /function liveup_fx:epic/diamant {player:"PseudoStreamer", viewer:"PseudoCadeau"}
# ============================================================

function liveup_fx:utils/cleanup

$execute as $(player) at @s run function liveup_fx:internal/spawn_beam
$execute as $(player) at @s run function liveup_fx:internal/spawn_pillars
$execute as $(player) at @s run function liveup_fx:internal/spawn_aura
$execute as $(player) at @s run function liveup_fx:internal/spawn_orbs

# Faisceau secondaire plus large
$execute as $(player) at @s run summon item_display ~ ~14 ~ {Tags:["liveup_fx","liveup_fx_beam"],item:{id:"minecraft:nether_star",count:1},item_display:"fixed",interpolation_duration:10,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,28f,0.8f]},brightness:{block:15,sky:15},view_range:3.5f}

$execute as $(player) at @s run playsound minecraft:ui.toast.challenge_complete master @a[distance=..50] ~ ~ ~ 1 1
$execute as $(player) at @s run playsound minecraft:block.beacon.power_select master @a[distance=..50] ~ ~ ~ 1 0.8
$execute as $(player) at @s run playsound minecraft:entity.lightning_bolt.thunder master @a[distance=..50] ~ ~ ~ 1.3 0.9
$execute as $(player) at @s run summon lightning_bolt ~ ~ ~

$cube diamant $(player) $(viewer)

schedule function liveup_fx:utils/cleanup 70t
