# ============================================================
# LIVEUP FX – TNT ÉPIQUE 3D
# Usage (TikFinity / console) :
#   /function liveup_fx:epic/tnt {player:"PseudoStreamer", n:"10", viewer:"PseudoCadeau"}
# ============================================================

# 1. Nettoyage éventuel précédent
function liveup_fx:utils/cleanup

# 2. Effets 3D autour du joueur
$execute as $(player) at @s run function liveup_fx:internal/spawn_beam
$execute as $(player) at @s run function liveup_fx:internal/spawn_pillars
$execute as $(player) at @s run function liveup_fx:internal/spawn_aura
$execute as $(player) at @s run function liveup_fx:internal/spawn_orbs

# 3. Sons (non-particules)
$execute as $(player) at @s run playsound minecraft:entity.lightning_bolt.thunder master @a[distance=..40] ~ ~ ~ 1.2 1.1
$execute as $(player) at @s run playsound minecraft:block.beacon.activate master @a[distance=..40] ~ ~ ~ 1 1.4
$execute as $(player) at @s run playsound minecraft:entity.elder_guardian.curse master @a[distance=..40] ~ ~ ~ 0.7 1.6

# 4. Éclair (entité, pas particule)
$execute as $(player) at @s run summon lightning_bolt ~ ~ ~

# 5. Appel de la vraie commande LiveUpCube (le plugin gère le reste)
$cube tnt $(player) $(n) $(viewer)

# 6. Nettoyage automatique après 2.5 secondes (50 ticks)
schedule function liveup_fx:utils/cleanup 50t
