# ============================================================
# LIVEUP FX – ROULETTE / GROS CADEAU 3D (le plus spectaculaire)
# Usage :
#   /function liveup_fx:epic/roulette {player:"PseudoStreamer", viewer:"PseudoCadeau"}
# ============================================================

function liveup_fx:utils/cleanup

$execute as $(player) at @s run function liveup_fx:internal/spawn_beam
$execute as $(player) at @s run function liveup_fx:internal/spawn_pillars
$execute as $(player) at @s run function liveup_fx:internal/spawn_aura
$execute as $(player) at @s run function liveup_fx:internal/spawn_orbs

# Deuxième faisceau décalé
$execute as $(player) at @s run summon item_display ~1.5 ~12 ~-1.5 {Tags:["liveup_fx","liveup_fx_beam"],item:{id:"minecraft:end_crystal",count:1},item_display:"fixed",interpolation_duration:10,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.2f,22f,0.2f]},brightness:{block:15,sky:15},view_range:3f}

$execute as $(player) at @s run playsound minecraft:entity.wither.spawn master @a[distance=..55] ~ ~ ~ 0.8 1.2
$execute as $(player) at @s run playsound minecraft:ui.toast.challenge_complete master @a[distance=..55] ~ ~ ~ 1 0.9
$execute as $(player) at @s run playsound minecraft:entity.lightning_bolt.thunder master @a[distance=..55] ~ ~ ~ 1.4 0.85
$execute as $(player) at @s run summon lightning_bolt ~ ~ ~
$execute as $(player) at @s run summon lightning_bolt ~2 ~ ~-1

$cube roulette $(player) $(viewer)

schedule function liveup_fx:utils/cleanup 80t
