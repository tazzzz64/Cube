# ============================================================
# LIVEUP FX – RETIRER (malus)
# Usage :
#   /function liveup_fx:epic/retirer {player:"PseudoStreamer", n:"20", viewer:"PseudoCadeau"}
# ============================================================

function liveup_fx:utils/cleanup

$execute as $(player) at @s run function liveup_fx:internal/spawn_aura

$execute as $(player) at @s run playsound minecraft:entity.generic.explode master @a[distance=..30] ~ ~ ~ 0.7 1.4
$execute as $(player) at @s run playsound minecraft:block.glass.break master @a[distance=..30] ~ ~ ~ 1 0.6

$cube retirer $(player) $(n) $(viewer)

schedule function liveup_fx:utils/cleanup 25t
