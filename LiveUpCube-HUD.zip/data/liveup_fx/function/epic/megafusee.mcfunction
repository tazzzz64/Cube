# ============================================================
# LIVEUP FX – MEGA FUSÉE 3D
# Usage :
#   /function liveup_fx:epic/megafusee {player:"PseudoStreamer", viewer:"PseudoCadeau"}
# ============================================================

function liveup_fx:utils/cleanup

$execute as $(player) at @s run function liveup_fx:internal/spawn_beam
$execute as $(player) at @s run function liveup_fx:internal/spawn_pillars
$execute as $(player) at @s run function liveup_fx:internal/spawn_aura
$execute as $(player) at @s run function liveup_fx:internal/spawn_orbs

# Anneaux supplémentaires
$execute as $(player) at @s run summon item_display ~ ~0.4 ~ {Tags:["liveup_fx","liveup_fx_ring"],item:{id:"minecraft:nether_star",count:1},item_display:"fixed",interpolation_duration:0,transformation:{left_rotation:[0.707f,0f,0f,0.707f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2.2f,0.2f,2.2f]},brightness:{block:15,sky:15},view_range:2.5f}

$execute as $(player) at @s run playsound minecraft:entity.wither.spawn master @a[distance=..50] ~ ~ ~ 0.7 1.4
$execute as $(player) at @s run playsound minecraft:entity.firework_rocket.launch master @a[distance=..50] ~ ~ ~ 1.4 0.5
$execute as $(player) at @s run summon lightning_bolt ~ ~ ~

$cube megafusee $(player) $(viewer)

schedule function liveup_fx:utils/cleanup 60t
