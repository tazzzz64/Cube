# LiveUp FX – chargé
tellraw @a[tag=liveup_fx_admin] [{"text":"[LiveUp FX] ","color":"aqua","bold":true},{"text":"Datapack chargé – effets 3D prêts.","color":"gray"}]
scoreboard objectives add liveup_fx dummy
scoreboard players set #version liveup_fx 1
