# Supprime tous les displays d'effet LiveUp FX
kill @e[type=item_display,tag=liveup_fx]
kill @e[type=block_display,tag=liveup_fx]
kill @e[type=text_display,tag=liveup_fx]
