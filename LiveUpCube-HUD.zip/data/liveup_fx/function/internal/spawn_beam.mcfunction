# Faisceau vertical 3D (item_display ultra-étiré)
# Utilise un item "glowing" – remplace facilement par un modèle custom de ton pack

# Base du faisceau (bas)
summon item_display ~ ~0.5 ~ {Tags:["liveup_fx","liveup_fx_beam"],item:{id:"minecraft:end_crystal",count:1},item_display:"fixed",interpolation_duration:0,start_interpolation:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.4f,0.4f,0.4f]},brightness:{block:15,sky:15},view_range:3f}

# Corps du faisceau (très allongé en Y)
summon item_display ~ ~12 ~ {Tags:["liveup_fx","liveup_fx_beam"],item:{id:"minecraft:end_crystal",count:1},item_display:"fixed",interpolation_duration:8,start_interpolation:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.25f,24f,0.25f]},brightness:{block:15,sky:15},view_range:3f}

# Pointe haute
summon item_display ~ ~24 ~ {Tags:["liveup_fx","liveup_fx_beam"],item:{id:"minecraft:nether_star",count:1},item_display:"fixed",interpolation_duration:6,start_interpolation:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.6f,0.6f,0.6f]},brightness:{block:15,sky:15},view_range:3f}

# Animation d'apparition (scale depuis 0)
data modify entity @e[type=item_display,tag=liveup_fx_beam,limit=1,sort=nearest] transformation.scale set value [0.01f,0.01f,0.01f]
data modify entity @e[type=item_display,tag=liveup_fx_beam,limit=1,sort=nearest] interpolation_duration set value 10
