# Orbes d'énergie flottants (explosion visuelle)

summon item_display ~2 ~3 ~2 {Tags:["liveup_fx","liveup_fx_orb"],item:{id:"minecraft:ender_eye",count:1},item_display:"fixed",interpolation_duration:15,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.01f,0.01f,0.01f]},brightness:{block:15,sky:15},view_range:2f}

summon item_display ~-2 ~4 ~-1 {Tags:["liveup_fx","liveup_fx_orb"],item:{id:"minecraft:ender_eye",count:1},item_display:"fixed",interpolation_duration:15,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.01f,0.01f,0.01f]},brightness:{block:15,sky:15},view_range:2f}

summon item_display ~1 ~5 ~-2 {Tags:["liveup_fx","liveup_fx_orb"],item:{id:"minecraft:heart_of_the_sea",count:1},item_display:"fixed",interpolation_duration:15,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.01f,0.01f,0.01f]},brightness:{block:15,sky:15},view_range:2f}

summon item_display ~-1.5 ~2.5 ~1.5 {Tags:["liveup_fx","liveup_fx_orb"],item:{id:"minecraft:heart_of_the_sea",count:1},item_display:"fixed",interpolation_duration:15,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.01f,0.01f,0.01f]},brightness:{block:15,sky:15},view_range:2f}

# Grossissement des orbes
execute as @e[type=item_display,tag=liveup_fx_orb] run data merge entity @s {transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.9f,0.9f,0.9f]}}
