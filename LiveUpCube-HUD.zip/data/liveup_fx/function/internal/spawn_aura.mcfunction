# Aura 3D tournante autour du joueur (plusieurs orbes)
# 6 item_display placés en cercle, rotation progressive

summon item_display ~1.8 ~1.2 ~ {Tags:["liveup_fx","liveup_fx_aura"],item:{id:"minecraft:amethyst_shard",count:1},item_display:"fixed",interpolation_duration:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.7f,0.7f,0.7f]},brightness:{block:15,sky:15},view_range:2f}

summon item_display ~-1.8 ~1.2 ~ {Tags:["liveup_fx","liveup_fx_aura"],item:{id:"minecraft:amethyst_shard",count:1},item_display:"fixed",interpolation_duration:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.7f,0.7f,0.7f]},brightness:{block:15,sky:15},view_range:2f}

summon item_display ~ ~1.2 ~1.8 {Tags:["liveup_fx","liveup_fx_aura"],item:{id:"minecraft:amethyst_shard",count:1},item_display:"fixed",interpolation_duration:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.7f,0.7f,0.7f]},brightness:{block:15,sky:15},view_range:2f}

summon item_display ~ ~1.2 ~-1.8 {Tags:["liveup_fx","liveup_fx_aura"],item:{id:"minecraft:amethyst_shard",count:1},item_display:"fixed",interpolation_duration:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.7f,0.7f,0.7f]},brightness:{block:15,sky:15},view_range:2f}

summon item_display ~1.3 ~1.8 ~1.3 {Tags:["liveup_fx","liveup_fx_aura"],item:{id:"minecraft:echo_shard",count:1},item_display:"fixed",interpolation_duration:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{block:15,sky:15},view_range:2f}

summon item_display ~-1.3 ~1.8 ~-1.3 {Tags:["liveup_fx","liveup_fx_aura"],item:{id:"minecraft:echo_shard",count:1},item_display:"fixed",interpolation_duration:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},brightness:{block:15,sky:15},view_range:2f}
