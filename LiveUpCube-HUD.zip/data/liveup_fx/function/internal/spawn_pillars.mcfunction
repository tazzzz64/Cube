# 4 piliers 3D qui montent aux coins de l'arène (offset ~6-7 blocs)
# Scale Y animé via interpolation

# Nord-Ouest
summon block_display ~-7 ~0.1 ~-7 {Tags:["liveup_fx","liveup_fx_pillar"],block_state:{Name:"minecraft:light_blue_stained_glass"},interpolation_duration:0,start_interpolation:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.5f,0f,-0.5f],scale:[1.2f,0.05f,1.2f]},brightness:{block:15,sky:15},view_range:2.5f}

# Nord-Est
summon block_display ~7 ~0.1 ~-7 {Tags:["liveup_fx","liveup_fx_pillar"],block_state:{Name:"minecraft:light_blue_stained_glass"},interpolation_duration:0,start_interpolation:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.5f,0f,-0.5f],scale:[1.2f,0.05f,1.2f]},brightness:{block:15,sky:15},view_range:2.5f}

# Sud-Ouest
summon block_display ~-7 ~0.1 ~7 {Tags:["liveup_fx","liveup_fx_pillar"],block_state:{Name:"minecraft:light_blue_stained_glass"},interpolation_duration:0,start_interpolation:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.5f,0f,-0.5f],scale:[1.2f,0.05f,1.2f]},brightness:{block:15,sky:15},view_range:2.5f}

# Sud-Est
summon block_display ~7 ~0.1 ~7 {Tags:["liveup_fx","liveup_fx_pillar"],block_state:{Name:"minecraft:light_blue_stained_glass"},interpolation_duration:0,start_interpolation:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.5f,0f,-0.5f],scale:[1.2f,0.05f,1.2f]},brightness:{block:15,sky:15},view_range:2.5f}

# Déclenche la montée (interpolation 12 ticks ≈ 0.6s)
execute as @e[type=block_display,tag=liveup_fx_pillar] run data merge entity @s {interpolation_duration:12,start_interpolation:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.5f,0f,-0.5f],scale:[1.2f,9f,1.2f]}}
